#include <stdio.h>
#include "tests/threads/tests.h"
#include "threads/init.h"
#include "threads/malloc.h"
#include "threads/synch.h"
#include "threads/thread.h"
#include "devices/timer.h"

/* Semaphore to force threads to wait */
static struct semaphore barrier_sema;

void edf_worker (void *aux);

void edf_worker (void *aux) 
{
  int duration = (int) aux;
  int64_t start_time = timer_ticks();
  
  /* 1. Set the deadline */
  int64_t deadline = start_time + duration;
  thread_set_deadline (deadline);
  
  msg ("Thread %s initialized. Deadline: %lld", thread_name(), deadline);
  
  /* 2. FORCE BLOCK: Use a semaphore to block.
     This guarantees the thread leaves the Ready List.
     When Main wakes us up, we will be re-inserted by Deadline. */
  sema_down (&barrier_sema);
  
  /* 3. Real work starts here (Sorted!) */
  msg ("Thread %s starting work.", thread_name());
  
  /* Busy wait to simulate CPU usage */
  while (timer_ticks () < start_time + duration + 10) 
    ; 
    
  msg ("Thread %s finished.", thread_name());
}

void
test_edf_simple (void) 
{
  msg ("Begin EDF Simple Test");
  
  /* Initialize the semaphore with 0. Everyone who downs it will block. */
  sema_init (&barrier_sema, 0);

  /* Create threads. They will run, set deadline, and BLOCK on the semaphore. */
  thread_create ("Late",   PRI_DEFAULT, edf_worker, (void *) 300);
  thread_create ("Medium", PRI_DEFAULT, edf_worker, (void *) 200);
  thread_create ("Urgent", PRI_DEFAULT, edf_worker, (void *) 100);

  /* Sleep briefly to ensure all threads have run and blocked on the semaphore */
  timer_sleep (100);
  
  msg ("Main thread waking up workers...");
  
  /* Wake them up! 
     thread_unblock() will be called for each, inserting them 
     into the Ready List sorted by DEADLINE. */
  sema_up (&barrier_sema); // Wake one
  sema_up (&barrier_sema); // Wake one
  sema_up (&barrier_sema); // Wake one

  /* Pass control to the workers */
  timer_sleep (1000);
  msg ("End EDF Simple Test");
}